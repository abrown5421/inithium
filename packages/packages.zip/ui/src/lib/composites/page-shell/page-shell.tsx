import React, { Suspense } from 'react';
import { Box } from '../../components/box/box';
import type { AnimationController, PageDefinition } from '@inithium/types';

interface PageShellProps {
  page: PageDefinition;
  controller: AnimationController;
}

export const PageShell: React.FC<PageShellProps> = ({ page, controller }) => {
  const animation = {
    entry: page.entry,
    exit: page.exit,
    entrySpeed: page.entrySpeed,
    exitSpeed: page.exitSpeed,
    controller,
  };

  const centeringProps = page.centered
    ? { align: 'center' as const, justify: 'center' as const }
    : {};

  return (
    <Box
      as="main"
      display="flex"
      direction="col"
      fullWidth
      fullHeight
      bg={page.bg}
      color={page.color}
      animation={animation}
      {...centeringProps}
    >
      <Suspense fallback={null}>
        <page.component />
      </Suspense>
    </Box>
  );
};